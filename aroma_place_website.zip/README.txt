AROMA PLACE — Static website
Files:
- index.html
- style.css
- script.js
- assets/ (placeholders images)

How to use:
1. Unzip and open index.html locally to test.
2. To deploy on GitHub Pages:
   - Create a repo (e.g., aroma-place-website).
   - Upload these files to the repo root.
   - In repo Settings -> Pages, select Branch: main and Folder: /root, Save.
   - Your site will be available at: https://yourusername.github.io/repo-name/

You can replace the placeholder images in /assets with your real images.
