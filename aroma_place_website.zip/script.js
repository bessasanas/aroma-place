// Simple cart interactions and small UI touches
document.getElementById('year').textContent = new Date().getFullYear();

const addBtns = document.querySelectorAll('.add-to-cart');
let cartCount = 0;
let cartTotal = 0;

addBtns.forEach(btn=>{
  btn.addEventListener('click', (e)=>{
    const name = btn.dataset.name;
    const price = Number(btn.dataset.price || 0);
    cartCount += 1;
    cartTotal += price;
    document.getElementById('cart-count').textContent = cartCount;
    document.getElementById('cart-total').textContent = cartTotal;
    btn.textContent = 'تم الإضافة';
    btn.disabled = true;
  });
});

// contact form simple feedback
const contactFormBtn = document.getElementById('send-contact');
contactFormBtn.addEventListener('click', ()=>{
  const name = document.getElementById('name').value || 'زائر';
  alert('شكراً ' + name + '، تم استلام رسالتك. سنرد عليك قريباً.');
});
